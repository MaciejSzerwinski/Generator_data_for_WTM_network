function [Neurons] = koh_neural_gas(Neurons,D,n,epochs,alpha0,lambda0)

%NEURAL_GAS Quantizes the data space using the neural gas algorithm.
%
% Neurons = neural_gas(D, n, epochs, [alpha0], [lambda0])
%
%   C = neural_gas(D,50,10);
%   sM = som_map_struct(sD); 
%   sM.codebook = neural_gas(sD,size(sM.codebook,1),10);
%
%  Input and output arguments ([]'s are optional):
%   D          (matrix) the data matrix, size dlen x dim
%              (struct) a data struct
%   n          (scalar) the number of neurons
%   epochs     (scalar) the number of training epochs (the number of
%                       training steps is dlen*epochs)
%   [alpha0]   (scalar) initial step size, 0.5 by default
%   [lambda0]  (scalar) initial decay constant, n/2 by default
%
%   Neurons    (matrix) the neuron matrix, size n x dim
%
% See also SOM_MAKE, KMEANS.

% References: 
%  T.M.Martinetz, S.G.Berkovich, and K.J.Schulten. "Neural-gas" network
%  for vector quantization and its application to time-series prediction. 
%  IEEE Transactions on Neural Networks, 4(4):558-569, 1993.

% Contributed to SOM Toolbox vs2, February 2nd, 2000 by Juha Vesanto
% Copyright (c) by Juha Vesanto
% http://www.cis.hut.fi/projects/somtoolbox/

% juuso 101297 020200

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Check arguments and initialize

error(nargchk(4, 6, nargin));  % check the number of input arguments

if isstruct(D), D = D.data; end
[dlen,dim] = size(D);
%Neurons = (rand(n,dim)-0.5)*10e-5; % small initial values
train_len = epochs*dlen;

if nargin<5 | isempty(alpha0) | isnan(alpha0), alpha0 = 0.5; end
if nargin<6 | isempty(lambda0) | isnan(lambda0), lambda0 = n/2; end

% random sample order
rand('state',sum(100*clock));
sample_inds = ceil(dlen*rand(train_len,1));

% lambda
%lambda = lambda0 * (0.01/lambda0).^([0:(train_len-1)]/train_len);
lambda = lambda0 * (0.01/lambda0).^([0:(train_len-1)]/train_len);

% alpha
%alpha = alpha0 * (0.005/alpha0).^([0:(train_len-1)]/train_len);
alpha = alpha0 * (0.08/alpha0).^([0:(train_len-1)]/train_len);

tracking = 10;
qe = 0;
trainlen = train_len;
update_step = 100; 
mu_x_1 = ones(n,1);
samples = ones(update_step,1);

start = clock;
if tracking >  0, % initialize tracking
  track_table = zeros(update_step,1);
  qe = zeros(floor(trainlen/update_step),1);  
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Action

for i=1:train_len,
  ind = rem(i,update_step); if ind==0, ind = update_step; end

  % sample vector
  x = D(sample_inds(i),:); % sample vector
  known = ~isnan(x);       % its known components
  X = x(ones(n,1),known);  % we'll need this 

  % neighborhood ranking
  Dx = Neurons(:,known) - X;  % difference between vector and all map units
  [qerrs, inds] = sort((Dx.^2)*known'); % 1-BMU, 2-BMU, etc.
  ranking(inds) = [0:(n-1)];             
  h = exp(-ranking/lambda(i));
  H = h(ones(length(known),1),:)';

  % update 
  Neurons = Neurons + alpha(i)*H.*(x(ones(n,1),known) - Neurons(:,known));

  % track
%  fprintf(1,'%d / %d \r',i,train_len);
%   if mod(i,50) == 1, 
%     hold off, plot3(D(:,1),D(:,2),D(:,3),'bo')
%     hold on, plot3(Neurons(:,1),Neurons(:,2),Neurons(:,3),'r+')
%     drawnow
%   end

  % find BMU
%  Dx = Neurons(:,known) - x(mu_x_1,known);     % each map unit minus the vector
%  [qerr bmu] = min((Dx.^2)*mask(known)); % minimum distance(^2) and the BMU
%  [qerr bmu] = min((Dx.^2)); % minimum distance(^2) and the BMU

 
  % tracking
   if tracking>0, 
%    track_table(ind) = sqrt(qerr(1));
     if mod(i,update_step) == 0,
       n_q = ceil(i/update_step); 

  [bmus qerrs]= som_bmus(Neurons,D,1);
  inds = find(~isnan(bmus(:,1)));
%  bmus = bmus(inds,:);
  qerrs = qerrs(inds,:);
%   l = length(inds);
%   if ~l, error('Empty data set.'); end

   % mean quantization error
   mqe = mean(qerrs(:,1));
       
       qe(n_q) = mqe;
       trackplot(Neurons,D,tracking,start,n_q,qe);
     end
   end
   
end

fprintf(1,'\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% subfunctions

%%%%%%%%
function [] = trackplot(M,D,tracking,start,n,qe)

  l = length(qe);
  elap_t = etime(clock,start); 
  tot_t = elap_t*l/n;

  f = findobj('Tag','learn_figure');
  str_time = sprintf('Training: %3.0f/ %3.0f s',elap_t,tot_t);
  set(f,'Name', ['Learning progress: ' str_time]);
  figure(f)
  
  switch tracking
   case 1, 
   case 2,       
    plot(1:n,qe(1:n),(n+1):l,qe((n+1):l))
    title('Quantization errors for latest samples')    
    drawnow
   otherwise,
    subplot(2,1,1), plot(1:n,qe(1:n),(n+1):l,qe((n+1):l))
    title('Quantization error for latest samples');
   subplot(2,1,2), 
    sw=plot(D(:,1),D(:,2),'b.'); 
    set(sw,'MarkerSize',6);
    hold on
    sw=plot(M(:,1),M(:,2),'ro');
    set(sw,'MarkerFaceColor','red');
    hold off
    title('First two components of map units (o) and data vectors (+)');
    drawnow
  end  
  % end of trackplot

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
