function kohon

addpath .\somtoolbox
addpath ..\mlp

kohon_mat