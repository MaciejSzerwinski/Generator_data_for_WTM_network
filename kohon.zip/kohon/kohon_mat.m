function varargout = kohon_mat(varargin)
% KOHON_MAT M-file for kohon_mat.fig
%      KOHON_MAT, by itself, creates a new KOHON_MAT or raises the existing
%      singleton*.
%
%      H = KOHON_MAT returns the handle to a new KOHON_MAT or the handle to
%      the existing singleton*.
%
%      KOHON_MAT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in KOHON_MAT.M with the given input arguments.
%
%      KOHON_MAT('Property','Value',...) creates a new KOHON_MAT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before kohon_mat_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to kohon_mat_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help kohon_mat

% Last Modified by GUIDE v2.5 16-Feb-2009 09:38:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @kohon_mat_OpeningFcn, ...
                   'gui_OutputFcn',  @kohon_mat_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before kohon_mat is made visible.
function kohon_mat_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to kohon_mat (see VARARGIN)

% Choose default command line output for kohon_mat
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes kohon_mat wait for user response (see UIRESUME)
% uiwait(handles.figure1);

[dim, neigh, lattice, shape, ini_type, alg, epoch, radius, alpha, lambda]=kohon_config();
setappdata(handles.figure1, 'dim', dim );
setappdata(handles.figure1, 'neigh', neigh );
setappdata(handles.figure1, 'lattice', lattice );
setappdata(handles.figure1, 'shape', shape );
setappdata(handles.figure1, 'ini_type', ini_type );
setappdata(handles.figure1, 'alg', alg );
setappdata(handles.figure1, 'epoch', epoch );
setappdata(handles.figure1, 'radius', radius );
setappdata(handles.figure1, 'alpha', alpha );
setappdata(handles.figure1, 'lambda', lambda );

set(handles.edit_dim, 'String', num2str(getappdata(handles.figure1, 'dim')));
set(handles.epoch_edit, 'String', num2str(getappdata(handles.figure1, 'epoch')));
set(handles.alpha_edit, 'String', num2str(getappdata(handles.figure1, 'alpha')));
set(handles.lambda_edit, 'String', num2str(getappdata(handles.figure1, 'lambda')));
set(handles.radius_edit, 'String', num2str(getappdata(handles.figure1, 'radius')));

setappdata(handles.figure1, 'sD', [] );

%set( handles.figure1, 'Units', 'Normalized' );
%pos = get( handles.figure1, 'Position' );
%set( handles.figure1, 'Position', [0.5-pos(3)/2 0.5-pos(4)/2 pos(3) pos(4)] );
set( handles.figure1, 'Visible', 'on' );


% --- Outputs from this function are returned to the command line.
function varargout = kohon_mat_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%[s,v] = listdlg('PromptString','Select a wariable', ...
%'SelectionMode','single',...
%'ListString',x)

som_error_n();

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

s = [];
shortfile = [];
file = [];

ask_str = 'Load learning data';

%   [filename, pathname] = uigetfile( ...
%       {'*.mat','MAT files (*.mat)'; ...
%        '*.txt','Text files (*.txt)'; ...
%        '*.dat','Text files (*.dat)'; ...
%        '*.csv','CSV files (*.csv)'; ...
%        '*.*',  'All files (*.*)'}, ...
%        ask_str );
  
[filename, pathname] = uigetfile( ...
       {'*.dat','Data files (*.dat)'; ...
       '*.data','Data files (*.dat)'; ...
       '*.txt','Text files (*.txt)'; ...
        '*.*',  'All files (*.*)'}, ...
        ask_str );
  
if filename == 0,
   return   
end

file = [pathname filename];
sD = som_read_data( file );
setappdata(handles.figure1, 'sD', sD );
setappdata(handles.figure1, 'sMap', [] );

cfig=findobj('Tag','learn_figure');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','sammon2d');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','sammon3d');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','voronoidiag');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','kohmap');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','kohmap_graph');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','learn_figure');
if ~isempty(cfig)
   close(cfig);
end



% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

s = [];
shortfile = [];
file = [];

ask_str = 'Load network';

%   [filename, pathname] = uigetfile( ...
%       {'*.mat','MAT files (*.mat)'; ...
%        '*.txt','Text files (*.txt)'; ...
%        '*.dat','Text files (*.dat)'; ...
%        '*.csv','CSV files (*.csv)'; ...
%        '*.*',  'All files (*.*)'}, ...
%        ask_str );
  
[filename, pathname] = uigetfile( ...
       {'*.cod','Code files (*.cod)'; ...
        '*.code','Code files (*.code)'; ...
        '*.*',  'All files (*.*)'}, ...
        ask_str );
  
if filename == 0,
   return   
end

file = [pathname filename];
sMap = som_read_cod( file );
setappdata(handles.figure1, 'sMap', sMap );


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

sMap = getappdata(handles.figure1, 'sMap' );
if isempty(sMap)
   errordlg( 'Network not exist. Please initialize map first', 'Error' );
   return
end

[filename, pathname] = uiputfile('untitled.cod', 'Save network as');
if filename == 0,
   return   
end

som_write_cod( sMap, [pathname filename] );


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
som_error_n();



% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

contents = get(hObject,'String');
neigh = contents{get(hObject,'Value')};
setappdata(handles.figure1, 'neigh', neigh );



% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2

contents = get(hObject,'String');
lattice = contents{get(hObject,'Value')};
setappdata(handles.figure1, 'lattice', lattice );


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3
contents = get(hObject,'String');
sheet = contents{get(hObject,'Value')};
setappdata(handles.figure1, 'sheet', sheet );


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu4.
function popupmenu4_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu4

contents = get(hObject,'String');
alg = contents{get(hObject,'Value')};

switch alg
   case 'WTA',  set(handles.radius_edit,'Enable','off');
                set(handles.radius_edit,'String','N/A');               
                set(handles.lambda_edit,'Enable','off');
                set(handles.lambda_edit,'String','N/A');
                set(handles.alpha_edit,'Enable','on');
                set(handles.alpha_edit,'String','0.5');

   case 'CWTA', set(handles.radius_edit,'Enable','off');
                set(handles.radius_edit,'String','N/A');               
                set(handles.lambda_edit,'Enable','off');
                set(handles.lambda_edit,'String','N/A');
                set(handles.alpha_edit,'Enable','on');
                set(handles.alpha_edit,'String','0.5');

   case 'Neural gas', set(handles.radius_edit,'Enable','off');
                set(handles.radius_edit,'String','N/A');               
                set(handles.lambda_edit,'Enable','on');
                dim = str2num(get(handles.edit_dim,'String'));
                munits = round((dim(1) * dim(2))/2);
                set(handles.lambda_edit,'String',num2str(munits));
                set(handles.alpha_edit,'Enable','on');
                set(handles.alpha_edit,'String','0.5');

   case 'WTM batch', set(handles.radius_edit,'Enable','off');
                set(handles.radius_edit,'String','N/A');               
                dim = str2num(get(handles.edit_dim,'String'));
                rad = round(min(dim)/2);
                set(handles.radius_edit,'Enable','on');
                set(handles.radius_edit,'String',num2str(rad));
                set(handles.lambda_edit,'Enable','off');
                set(handles.lambda_edit,'String','N/A');
                set(handles.alpha_edit,'Enable','on');
                set(handles.alpha_edit,'String','0.2');

   case 'WTM seq', set(handles.radius_edit,'Enable','off');
                set(handles.radius_edit,'String','N/A');               
                dim = str2num(get(handles.edit_dim,'String'));
                rad = round(min(dim)/2);
                rad = round(max(dim)/2);
                set(handles.radius_edit,'Enable','on');
                set(handles.radius_edit,'String',num2str(rad));
                set(handles.lambda_edit,'Enable','off');
                set(handles.lambda_edit,'String','N/A');
                set(handles.alpha_edit,'Enable','on');
                set(handles.alpha_edit,'String','0.05');
end

setappdata(handles.figure1, 'alg', alg );



% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

sMap = getappdata(handles.figure1, 'sMap' );
if isempty(sMap)
   errordlg( 'Please initialize map first', 'Error' );
   return
end

sD = getappdata(handles.figure1, 'sD' );
if isempty(sD)
   errordlg( 'Please load the data first', 'Error' );
   return
end

neigh = getappdata(handles.figure1, 'neigh' );
lattice = getappdata(handles.figure1, 'lattice' );
shape = getappdata(handles.figure1, 'shape' );
ini_type = getappdata(handles.figure1, 'ini_type' );
epoch = getappdata(handles.figure1, 'epoch' );
radius = getappdata(handles.figure1, 'radius' );
lambda = getappdata(handles.figure1, 'lambda' );
alpha = getappdata(handles.figure1, 'alpha' );

alg = getappdata(handles.figure1, 'alg' );

f=figure(191);
set(f,'Tag','learn_figure');
set(f,'Units','normalized');
set(f,'Position', [0.6469 0.0283 0.3500    0.9058] );
set(f,'NumberTitle','off');
%set(f,'MenuBar','off'
set(f,'Name', 'Learning progress');

switch alg,
   case 'WTA', fprintf('Starting WTA ... ');
    [sMap] = som_kscwta(sMap, sD, epoch, alpha, 0 );

   case 'CWTA', fprintf('Starting CWTA ... ');
    [sMap] = som_kscwta(sMap, sD, epoch, alpha, 1 );

   case 'WTM batch', fprintf('Starting WTM batch ... ');
     [sMap,sT] = som_batchtrain(sMap, sD,  ...
     'radius_ini', radius, ...
     'radius_fin', 1, ...
     'tracking', 3, ...
     'trainlen', epoch, ...
     'neigh', neigh, ...
     'lattice', lattice, ...
     'shape', shape );
 

%  'alpha_type', 'inv', ... 
   case 'WTM seq', fprintf('Starting WTM seq ... ');
   [sMap,sT] = som_seqtrain(sMap, sD, ...
      'tracking', 3, ...
      'trainlen', epoch, ...
      'trainlen_type', 'epochs', ...
      'alpha_type', 'linear', ... 
      'sample_order', 'random', ...
      'radius_ini', radius, ...
      'radius_fin', 1, ...
      'alpha_ini', alpha, ...
      'neigh', neigh, ...
      'lattice', lattice, ...
      'shape', shape );
      
   case 'Neural gas', fprintf('Starting neural gas algorithm ... ');
     sMap.codebook = koh_neural_gas(sMap.codebook,sD, size(sMap.codebook,1), epoch, alpha, lambda);
end      

fprintf(' done\n');
setappdata(handles.figure1, 'sMap', sMap );

disp_errors(sMap,sD);


function epoch_edit_Callback(hObject, eventdata, handles)
% hObject    handle to epoch_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of epoch_edit as text
%        str2double(get(hObject,'String')) returns contents of epoch_edit as a double

epoch = str2num(get(hObject,'String'));
[a b] = size(epoch);
set(hObject,'ForegroundColor','black');
if isempty( epoch ) | b ~= 1 | a ~= 1,
   errordlg( 'Wrong number of epochs', 'Error', 'modal');
   set(hObject,'ForegroundColor','red');
   return
end
setappdata(handles.figure1, 'epoch', epoch );


% --- Executes during object creation, after setting all properties.
function epoch_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to epoch_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function radius_edit_Callback(hObject, eventdata, handles)
% hObject    handle to radius_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of radius_edit as text
%        str2double(get(hObject,'String')) returns contents of radius_edit as a double

radius = str2num(get(hObject,'String'));
[a b] = size(radius);
set(hObject,'ForegroundColor','black');
if isempty( radius ) | b ~= 1 | a ~= 1,
   errordlg( 'Wrong radius', 'Error', 'modal');
   set(hObject,'ForegroundColor','red');
   return
end
setappdata(handles.figure1, 'radius', radius );


% --- Executes during object creation, after setting all properties.
function radius_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to radius_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function alpha_edit_Callback(hObject, eventdata, handles)
% hObject    handle to alpha_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of alpha_edit as text
%        str2double(get(hObject,'String')) returns contents of alpha_edit as a double

alpha = str2num(get(hObject,'String'));
[a b] = size(alpha);
set(hObject,'ForegroundColor','black');
if isempty( alpha ) | b ~= 1 | a ~= 1,
   errordlg( 'Wrong number of epochs', 'Error', 'modal');
   set(hObject,'ForegroundColor','red');
   return
end
setappdata(handles.figure1, 'alpha', alpha );


% --- Executes during object creation, after setting all properties.
function alpha_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to alpha_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lambda_edit_Callback(hObject, eventdata, handles)
% hObject    handle to lambda_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lambda_edit as text
%        str2double(get(hObject,'String')) returns contents of lambda_edit as a double

lambda = str2num(get(hObject,'String'));
[a b] = size(lambda);
set(hObject,'ForegroundColor','black');
if isempty( lambda ) | b ~= 1 | a ~= 1,
   errordlg( 'Wrong lambda', 'Error', 'modal');
   set(hObject,'ForegroundColor','red');
   return
end
setappdata(handles.figure1, 'lambda', lambda );


% --- Executes during object creation, after setting all properties.
function lambda_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lambda_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in graph_button.
function graph_button_Callback(hObject, eventdata, handles)
% hObject    handle to graph_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

sMap = getappdata(handles.figure1, 'sMap' );
if isempty(sMap)
   errordlg( 'Please initialize map first', 'Error' );
   return
end

sD = getappdata(handles.figure1, 'sD' );
if isempty(sD)
   errordlg( 'Please load the data first', 'Error' );
   return
end

[lw,lk] = size(sMap.codebook);

if lk>3,
   errordlg( 'First two components of map and data are presented', 'Error', 'modal' );

   f=figure(148);
   set(f,'NumberTitle','off');
   set(f,'Name', 'Kohonen map');
   set(f,'Tag','kohmap');

   set( f, 'Units', 'Normalized' );
   pos = get( f, 'Position' );
   set( f, 'Position', [0.005 0.52 0.4 0.4] );
   
   clf
   sw=plot(sD.data(:,1),sD.data(:,2),'.b');
   set(sw,'MarkerSize',6);
   hold on
   sw=plot(sMap.codebook(:,1),sMap.codebook(:,2),'or');
   set(sw,'MarkerSize',6);
   set(sw,'MarkerFaceColor','red');
   [qe,te] = som_quality(sMap, sD);
   title(['QError=' num2str(qe) ', topographic error=' num2str(te)]);
end

if lk == 2,
   f=figure(148);
   set(f,'NumberTitle','off');
   set(f,'Name', 'Kohonen map');
   set(f,'Tag','kohmap');

   set( f, 'Units', 'Normalized' );
   pos = get( f, 'Position' );
   set( f, 'Position', [0.005 0.52 0.4 0.4] );
   
   clf
   sw=plot(sD.data(:,1),sD.data(:,2),'.b');
   set(sw,'MarkerSize',6);
   hold on
   som_grid(sMap,'Coord',sMap.codebook,'MarkerSize', 6, 'MarkerColor', 'red','LineColor', 'black');
   [qe,te] = som_quality(sMap, sD);
   title(['QError=' num2str(qe) ', topographic error=' num2str(te)]);
else
   if lk == 3
      f=figure(148);
      set(f,'NumberTitle','off');
      set(f,'Name', 'Kohonen map');
      set(f,'Tag','kohmap');
      
      set( f, 'Units', 'Normalized' );
      pos = get( f, 'Position' );
      set( f, 'Position', [0.005 0.52 0.4 0.4] );
      
      clf
      sw=plot3(sD.data(:,1),sD.data(:,2),sD.data(:,3),'.b');
      set(sw,'MarkerSize',6);
      hold on
      som_grid(sMap,'Coord',sMap.codebook,'MarkerSize', 6, 'MarkerColor', 'red','LineColor', 'black');
      [qe,te] = som_quality(sMap, sD);
      title(['QError=' num2str(qe) ', topographic error=' num2str(te)]);
   end
end


% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function edit_dim_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_dim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

sD = getappdata(handles.figure1, 'sD' );
if isempty(sD)
   errordlg( 'Please load the data first', 'Error' );
   return
end

dim = getappdata(handles.figure1, 'dim' );
lattice = getappdata(handles.figure1, 'lattice' );
shape = getappdata(handles.figure1, 'shape' );
ini_type = getappdata(handles.figure1, 'ini_type' );

if strcmp(ini_type,'randinit'),
   sMap = som_randinit(sD, 'msize', dim, 'lattice', lattice, 'shape', shape );
else
   sMap = som_lininit(sD, 'msize', dim, 'lattice', lattice, 'shape', shape );
end   

setappdata(handles.figure1, 'sMap', sMap );
fprintf('initialize ok\n');

disp_errors(sMap,sD);

% --- Executes on selection change in popupmenu5.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu5 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu5

contents = get(hObject,'String');
ini_type = contents{get(hObject,'Value')};
setappdata(handles.figure1, 'ini_type', ini_type );



function edit_dim_Callback(hObject, eventdata, handles)
% hObject    handle to edit_dim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_dim as text
%        str2double(get(hObject,'String')) returns contents of edit_dim as a double

dim = str2num(get(hObject,'String'));
[a b] = size(dim);
set(hObject,'ForegroundColor','black');
if isempty( dim ) | b ~= 2 | a ~= 1,
   errordlg( 'Wrong network dimensions', 'Error', 'modal');
   set(hObject,'ForegroundColor','red');
   return
end
setappdata(handles.figure1, 'dim', dim );


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

sMap = getappdata(handles.figure1, 'sMap' );
if isempty(sMap)
   errordlg( 'Please initialize map first', 'Error' );
   return
end

sD = getappdata(handles.figure1, 'sD' );
if isempty(sD)
   errordlg( 'Please load the data first', 'Error' );
   return
end

[lwm,lkm]=size(sMap.codebook);
[lwd,lkd]=size(sD.data);

if lkm>2,
   d=[sMap.codebook ; sD.data];
   D2=sammon(d,2);

   f=figure(329);
   set(f,'NumberTitle','off');
   set(f,'Name', '2D Sammon projection');
   set(f,'Tag','sammon2d');

   set( f, 'Units', 'Normalized' );
   pos = get( f, 'Position' );
   set( f, 'Position', [0.35 0.52 0.4 0.4] );

   clf
   %som_grid(sMap,'Coord',P_sm) 
   sw=plot(D2(lwm+1:end,1),D2(lwm+1:end,2),'.b');
   set(sw,'MarkerSize',6);
   hold on
   sw=plot(D2(1:lwm,1),D2(1:lwm,2),'or');
   set(sw,'MarkerFaceColor','red');

   [qe,te] = som_quality(sMap, sD);
   title(['QError=' num2str(qe) ', topographic error=' num2str(te)]);
else
   fprintf( 2, '\nData dimension should be greater than 2\n');
end

% --- Executes on button press in sammon3d_pushbutton.
function sammon3d_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to sammon3d_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

sMap = getappdata(handles.figure1, 'sMap' );
if isempty(sMap)
   errordlg( 'Please initialize map first', 'Error' );
   return
end

sD = getappdata(handles.figure1, 'sD' );
if isempty(sD)
   errordlg( 'Please load the data first', 'Error' );
   return
end

[lwm,lkm]=size(sMap.codebook);
[lwd,lkd]=size(sD.data);

if lkm>3,
   d=[sMap.codebook ; sD.data];
   D3=sammon(d,3);

   f=figure(130);
   set(f,'NumberTitle','off');
   set(f,'Name', '3D Sammon projection');
   set(f,'Tag','sammon3d');

   set( f, 'Units', 'Normalized' );
   pos = get( f, 'Position' );
   set( f, 'Position', [0.35 0.05 0.4 0.4] );

   clf
   %som_grid(sMap,'Coord',P_sm) 
   sw=plot3(D3(lwm+1:end,1),D3(lwm+1:end,2),D3(lwm+1:end,3),'.b');
   set(sw,'MarkerSize',6);
   hold on
   sw=plot3(D3(1:lwm,1),D3(1:lwm,2),D3(1:lwm,3),'or');
   set(sw,'MarkerFaceColor','red');

   [qe,te] = som_quality(sMap, sD);
   title(['QError=' num2str(qe) ', topographic error=' num2str(te)]);
else
   fprintf( 2, '\nData dimension should be greater than 3\n');
end



% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


sMap = getappdata(handles.figure1, 'sMap' );
if isempty(sMap)
   errordlg( 'Please initialize map first', 'Error' );
   return
end

sD = getappdata(handles.figure1, 'sD' );
if isempty(sD)
   errordlg( 'Please load the data first', 'Error' );
   return
end

[lwm,lkm]=size(sMap.codebook);
[lwd,lkd]=size(sD.data);

if lkm == 2,
   f=figure(201);
   set(f,'NumberTitle','off');
   set(f,'Name', 'Voronoi diagram');
   set(f,'Tag','voronoidiag');
   
   set( f, 'Units', 'Normalized' );
   pos = get( f, 'Position' );
   set( f, 'Position', [0.4005 0.05 0.4 0.4] );
   
   clf
   sw=plot(sD.data(:,1),sD.data(:,2),'.b');
   set(sw,'MarkerSize',6);
   hold on
   cc=get(f,'defaultaxescolororder');
   cc(1,:)=[1 0 0];
   set(f,'defaultaxescolororder',cc);
   
   voronoi(sMap.codebook(:,1),sMap.codebook(:,2),'o','red');
   axis('equal');
else
   fprintf( 2, '\nData dimension should be equal 2\n');
end


% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

s = [];
shortfile = [];
file = [];

ask_str = 'Load testing data';

%   [filename, pathname] = uigetfile( ...
%       {'*.mat','MAT files (*.mat)'; ...
%        '*.txt','Text files (*.txt)'; ...
%        '*.dat','Text files (*.dat)'; ...
%        '*.csv','CSV files (*.csv)'; ...
%        '*.*',  'All files (*.*)'}, ...
%        ask_str );
  
[filename, pathname] = uigetfile( ...
       {'*.dat','Data files (*.dat)'; ...
       '*.data','Data files (*.dat)'; ...
       '*.txt','Text files (*.txt)'; ...
        '*.*',  'All files (*.*)'}, ...
        ask_str );
  
if filename == 0,
   return   
end

file = [pathname filename];
sD_test = som_read_data( file );

[mpath, mname, mext] = fileparts( filename );

setappdata(handles.figure1, 'sD_test', sD_test );
setappdata(handles.figure1, 'test_file_name', mname );


% --- Executes on button press in pushbutton17.
function pushbutton17_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
som_error_n();




% --- Executes on button press in pushbutton18.
function pushbutton18_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

sMap = getappdata(handles.figure1, 'sMap' );
if isempty(sMap)
   errordlg( 'Please initialize and learn map first', 'Error' );
   return
end

sD_test = getappdata(handles.figure1, 'sD_test' );
if isempty(sD_test)
   errordlg( 'Please load the testing data first', 'Error' );
   return
end

num_neurons = size( sMap.codebook, 1 );
num_data = size( sD_test.data, 1 );
dim_data = size( sD_test.data, 2 );

test_file_name = getappdata(handles.figure1, 'test_file_name' );
file_idx = [test_file_name '.idx'];
file_tab = [test_file_name '.tab'];
  
fid_idx = fopen( file_idx, 'wt' );
if fid_idx < 1,
   error( ['Error creating file ', file_idx] );
end

fid_tab = fopen( file_tab, 'wt' );
if fid_tab < 1,
   error( ['Error creating file ', file_tab] );
end

fprintf( 'Start testing ... ' );

for d=1:num_data
   odl = som_eucdist2(sMap, sD_test.data(d,:));
   [wodl,zwyc] = min(odl);

   fprintf( fid_idx, '%d\n', zwyc );
   
   for i=1:dim_data,
      fprintf( fid_tab, '%f\n', sMap.codebook(zwyc,i) );
   end
end

fclose( fid_idx );
fclose( fid_tab );

fprintf( 'DONE.\n' );
fprintf( ['Results saved to ' file_idx ' and ' file_tab '\n']);


% --- Executes during object deletion, before destroying properties.
function figure1_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


cfig=findobj('Tag','learn_figure');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','sammon2d');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','sammon3d');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','voronoidiag');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','kohmap');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','kohmap_graph');
if ~isempty(cfig)
   close(cfig);
end

cfig=findobj('Tag','learn_figure');
if ~isempty(cfig)
   close(cfig);
end



% --- Executes during object creation, after setting all properties.
function uipanel10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes on button press in map_button.
function map_button_Callback(hObject, eventdata, handles)
% hObject    handle to map_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

sMap = getappdata(handles.figure1, 'sMap' );
if isempty(sMap)
   errordlg( 'Please initialize map first', 'Error' );
   return
end

sD = getappdata(handles.figure1, 'sD' );
if isempty(sD)
   errordlg( 'Please load the data first', 'Error' );
   return
end

f=figure(318);
set(f,'NumberTitle','off');
set(f,'Name', 'Kohonen map');
set(f,'Tag','kohmap_graph');

set( f, 'Units', 'Normalized' );
pos = get( f, 'Position' );
set( f, 'Position', [0.005 0.052 0.4 0.4] );
   
clf

%subplot(2,1,1)
%C = som_colorcode(sMap,'rgb4');
C = som_colorcode(sMap);
%som_cplane(sMap,C);
%title('Color code')


sM1=som_autolabel(sMap,sD,'vote');
sM=som_autolabel(sMap,sD,'freq');
som_show(sM,'empty','Labels','norm', 'd', 'empty','Labels','norm', 'd');
%som_show_add('label',sM,'subplot',1);
som_show_add('label',sM1,'subplot',2);

subplot(1,2,1)
U = som_umat(sMap);
Um = U(1:2:size(U,1),1:2:size(U,2));

som_cplane(sMap,C,1-Um(:)/max(Um(:)));
title('Color coding + distance matrix')

return


[Pd,V,me] = pcaproj(sD.data,2);        % project the data
Pm        = pcaproj(sMap.codebook,V,me); % project the prototypes
C = som_colorcode(Pm);  % Pm is the PC-projection calculated earlier
som_cplane(sMap,C)

som_cplane(sMap.topol.lattice,sMap.topol.msize,sMap.codebook(:,1));
u=som_umat(sMap);
h=som_cplane([sMap.topol.lattice 'U'], sMap.topol.msize, u(:));
set(h,'edgecolor','none');
m=sMap.codebook(:,1);
m=m-min(m);
m=m/max(m);

som_cplane(sMap.topol.lattice, sMap.topol.msize,'w',sqrt(m));

som_grid(sMap)
som_grid(sMap, 'coord', sMap.codebook(:,[1 2 3]));
S=som_grid(sMap, 'surf', sMap.codebook(:,4), 'marker','none', 'line', 'none');
S=som_grid(S,'coord', sMap.codebook(:,[1 2 3]));
som_cplane(sMap.topol.lattice, sMap.topol.msize, 'none'); hold on
som_grid(sMap,'Label', sMap.labels, 'Labelcolor','b');

%som_show_gui(sMap)

