function img2koh_save_dat

global org_img 
global xdim 
global ydim
global xdim_ramy
global ydim_ramy
global rozm_ramy
global liczba_ram
global img_fname
global image_shortname

%[filename, pathname] = uiputfile( '*.dat', 'Save as' );
[filename, pathname] = uiputfile( [image_shortname '.dat'], 'Save as' );

if filename == 0,
   return;
end

if ~isempty( pathname ) 
   fname = [pathname filename];
else
   fname = filename;
end

[pathstr,name,ext] = fileparts( fname );

if isempty(ext)
   ext = '.dat';
   fname = [fname ext];
end

bat_name = fullfile( pathstr, [name '.bat'] );
tab_name = fullfile( pathstr, [name '.tab'] );
mat_name = fullfile( pathstr, [name '.mat'] );

[fid, message] = fopen( fname, 'wt+' );
if fid < 0,
   errordlg( message, 'Error opening file', 'modal' );
   return
end

%[fid_tab, message] = fopen( tab_name, 'wt+' );
%if fid_tab < 0,
%   errordlg( message, 'Error opening file', 'modal' );
%   return
%end

if max(max(org_img)) > 1,
   max_img = 255;
else
   max_img = 1;
end

img_mat = zeros( xdim_ramy*ydim_ramy, floor(xdim/xdim_ramy)*floor(ydim/ydim_ramy) );

fprintf( fid, '%d\n', rozm_ramy );

h = waitbar(0,'Please wait...');
set( h, 'Resize', 'on' );

screenSize = get(0,'ScreenSize');
axFontSize=get(0,'FactoryAxesFontSize');
pointsPerPixel = 72/get(0,'ScreenPixelsPerInch');
width = 360 * pointsPerPixel;
height = 75 * pointsPerPixel;
pos = [screenSize(3)/2-width/2 screenSize(4)/2-height/2 width height];

set( h, 'Position', pos );

licz = 1;
for i=1:floor(xdim/xdim_ramy),
   for j=1:floor(ydim/ydim_ramy),
      
      licz2 = 1;
      for w=1:xdim_ramy,
         for c=1:ydim_ramy,
%            fprintf( fid, '%d %d -> %f\n', (i-1)*xdim_ramy+w, (j-1)*ydim_ramy+c, double(org_img( (i-1)*xdim_ramy+w, (j-1)*ydim_ramy+c ))/255 );
            fprintf( fid, '%f ', double(org_img( (i-1)*xdim_ramy+w, (j-1)*ydim_ramy+c ))/max_img );
%            fprintf( fid_tab, '%f\n', double(org_img( (i-1)*xdim_ramy+w, (j-1)*ydim_ramy+c ))/max_img );
            img_mat(licz2,licz) = double(org_img( (i-1)*xdim_ramy+w, (j-1)*ydim_ramy+c ))/max_img;
            licz2=licz2+1;
         end
      end
      
%       v = double(reshape( org_img( (i-1)*xdim_ramy+1:(i-1)*xdim_ramy+xdim_ramy, (j-1)*ydim_ramy+1:(j-1)*ydim_ramy+ydim_ramy ), 1, xdim_ramy*xdim_ramy ));
% 
%       fprintf( fid, '%.6f ', v./max_img );
% %      fprintf( fid, '%f ', v  );
      
      fprintf( fid, '\n' );
      waitbar( licz/liczba_ram, h );
      licz = licz +1;
   end
end
close(h)

fclose( fid );

img_mat=img_mat';
save( mat_name, 'img_mat' );

fid2 = fopen( bat_name, 'wt+' );
if fid2 < 0,
   errordlg( message, 'Error opening file', 'modal' );
   return
end

fprintf( fid2, '@call koh2pcx %s %d %d %s\n', tab_name, xdim/xdim_ramy, ydim/ydim_ramy, img_fname );

fclose( fid2 );

% fclose( fid_tab );
