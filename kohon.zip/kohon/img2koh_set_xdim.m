function img2koh_set_xdim
