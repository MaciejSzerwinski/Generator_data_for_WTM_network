function som_error_n

errordlg( 'Not ready yet', 'Error', 'modal' );