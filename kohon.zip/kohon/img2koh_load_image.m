function img2koh_load_image

global org_img 
global org_img_cm
global img_fname
global image_shortname
global xdim 
global ydim
global xdim_ramy
global ydim_ramy
global rozm_ramy
global liczba_ram
global nname

im_matlab_version = str2num(strtok(version, '.' )); 

%if im_matlab_version < 6,
   [filename, pathname] = uigetfile( '*.pcx', 'Select image file' );
   %else
%	[filename, pathname] = uigetfile( {'*.jpg;*.tif;*.bmp;*.pcx', 'All IMAGE files'; ...
%	        '*.*',          'All Files (*.*)'}, ...
%   	     'Select ORIGINAL file' );      
%end

if filename == 0,
	org_img = [];
	org_img_cm = [];
   img_fname = [];
	return   
end

if ~isempty( pathname ) 
   fname = [pathname filename];
else
   fname = filename;
end

img_fname = fname;

[im, cm] = imread( fname );

if length(size(im)) ~= 2,
   errordlg( 'Only grayscale images are allowed', 'Error', 'modal' );
   return
end

[xdim, ydim] = size( im );

org_img = im;
org_img_cm = cm;

cax = findobj( 'Tag','IMG2KOH_axes' );
axes( cax );
IMG2DIFF_image_1 = image( im );
colormap( cm );
axis image off
set( cax, 'Tag','IMG2KOH_axes' );

% obliczenia
px_p4 = 0;
px_p3 = 0;
xdim_ramy = [];
if mod(xdim,9) == 0,
   xdim_ramy = [xdim_ramy 9];
end
if mod(xdim,8) == 0,
   xdim_ramy = [xdim_ramy 8];
end
if mod(xdim,7) == 0,
   xdim_ramy = [xdim_ramy 7];
end
if mod(xdim,6) == 0,
   xdim_ramy = [xdim_ramy 6];
end
if mod(xdim,5) == 0,
   xdim_ramy = [xdim_ramy 5];
end
if mod(xdim,4) == 0,
   xdim_ramy = [xdim_ramy 4];
   px_p4 = 1;
end
if mod(xdim,3) == 0,
   xdim_ramy = [xdim_ramy 3];
   px_p3 = 1;
end
if mod(xdim,2) == 0,
   xdim_ramy = [xdim_ramy 2];
end
xdim_ramy = min(xdim_ramy);
if xdim_ramy == 2 & px_p4 == 1,
   xdim_ramy = 4;
end
if xdim_ramy == 2 & px_p3 == 1,
   xdim_ramy = 3;
end

py_p4 = 0;
py_p3 = 0;
ydim_ramy = [];
if mod(ydim,9) == 0,
   ydim_ramy = [ydim_ramy 9];
end
if mod(ydim,8) == 0,
   ydim_ramy = [ydim_ramy 8];
end
if mod(ydim,7) == 0,
   ydim_ramy = [ydim_ramy 7];
end
if mod(ydim,6) == 0,
   ydim_ramy = [ydim_ramy 6];
end
if mod(ydim,5) == 0,
   ydim_ramy = [ydim_ramy 5];
end
if mod(ydim,4) == 0,
   ydim_ramy = [ydim_ramy 4];
   py_p4 = 1;
end
if mod(ydim,3) == 0,
   ydim_ramy = [ydim_ramy 3];
   py_p3 = 1;
end
if mod(ydim,2) == 0,
   ydim_ramy = [ydim_ramy 2];
end
ydim_ramy = min(ydim_ramy);
if ydim_ramy == 2 & py_p4 == 1,
   ydim_ramy = 4;
end
if ydim_ramy == 2 & py_p3 == 1,
   ydim_ramy = 3;
end

img2koh_compute;

[pathstr,name,ext] = fileparts(fname);

image_shortname = name;
nname = 'Img2Koh';
hfig  = findobj( 'Tag', nname );
set( hfig, 'Name', [nname ' - ' name ext ] );
