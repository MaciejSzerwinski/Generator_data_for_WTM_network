function img2diff_comp_diff

global res_img
global res_img_cm
global org_img
global org_img_cm
global IMG2DIFF_image_3
global lw lc

%diff_img = abs((double(org_img) - double(res_img))./double(org_img))*100;
diff_img = abs(double(org_img) - double(res_img));

mse = sum(sum((diff_img.^2)));
mse = mse./(lw*lc);

p_snr = 10*log10(255^2/mse);

assignin( 'base', 'mse', mse );
assignin( 'base', 'psnr', p_snr  );
assignin( 'base', 'img_diff', diff_img );

cax = findobj( 'Tag', 'IMG2DIFF_axes_3' );
axes( cax );
IMG2DIFF_image_3 = imagesc( diff_img );
colormap( org_img_cm );
axis image off
set( cax, 'Tag','IMG2DIFF_axes_3' );

text_res = findobj( 'Tag', 'Result_TEXT' );
set( text_res, 'Visible', 'on' );

if max(max(org_img)) > 1,
   pmse = mse ./ 255;
   set( text_res, 'String', ['MSE = ' num2str(mse) '           PMSE = ' num2str(pmse) '           SNR = ' num2str(p_snr) ' dB'] );
else
   set( text_res, 'String', ['MSE = ' num2str(mse) '           SNR = ' num2str(p_snr) ' dB'] );
end

assignin( 'base', 'pmse', pmse );

%sec_butt = findobj( 'Tag', 'LoadRESImage' );
%set( sec_butt, 'Enable', 'off' );

%sec_butt = findobj( 'Tag', 'ComputeDIFF' );
%set( sec_butt, 'Enable', 'off' );
