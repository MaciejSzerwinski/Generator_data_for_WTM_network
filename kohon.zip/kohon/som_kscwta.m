function [sMap] = som_kscwta(sMap, sD, epoch, alpha0, alg_type );

% tracking 
start = clock; update_step = 100;
tracking = 10;

num_neurons = size( sMap.codebook, 1 );
licz_zw = ones( num_neurons, 1 );

num_data = size( sD.data, 1 );
no_samples = epoch*num_data;
trainlen = no_samples;
   
qe = zeros(epoch,1); 

cwta_mod = 1;
    
l=0;
for it=1:epoch
   
   sD.data = sD.data(randperm(num_data),:);

   lr = alpha0 * (1.0 - (it/epoch));
      
%   if it < 4,
%      cwta_mod = 1;
      %disp('Wylaczam sumienie');
%   end
   
   for d=1:num_data
      zwyc = compcs( sMap, sD, d, licz_zw, cwta_mod, alg_type  );
%      zwyc = compcs( sMap, sD, d, licz_zw, 1  );
      licz_zw(zwyc) = licz_zw(zwyc) + 1;
      
%      lr = alpha0 * (1.0 - (l/no_samples));
      
		sMap.codebook(zwyc,:) = sMap.codebook(zwyc,:) + lr * (sD.data(d,:) - sMap.codebook(zwyc,:));
      l=l+1;
      
      % tracking
      if tracking>0, 
   %    track_table(ind) = sqrt(qerr(1));
         if mod(l,update_step) == 0,
            n_q = ceil(l/update_step); 
            [bmus qerrs]= som_bmus(sMap,sD,1);
            inds = find(~isnan(bmus(:,1)));
         %  bmus = bmus(inds,:);
            qerrs = qerrs(inds,:);
         %   l = length(inds);
         %   if ~l, error('Empty data set.'); end

         % mean quantization error
            mqe = mean(qerrs(:,1));
            qe(it) = mqe;
            trackplot(sMap,sD,tracking,start,it,real(qe));
         end
      end
   end
end

licz_zw

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% subfunctions
function zwyc = compcs( sMap, sD, d, licz_zw, cwta_mod, alg_type  )

odl = som_eucdist2(sMap, sD.data(d,:));
if cwta_mod & alg_type,
   odl = odl.*licz_zw;
   %odl = odl.*licz_zw;
   %odl = odl.*licz_zw;
end

[wodl,zwyc] = min(odl);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = trackplot(M,D,tracking,start,n,qe)

  l = length(qe);
  elap_t = etime(clock,start); 
  tot_t = elap_t*l/n;

  f = findobj('Tag','learn_figure');
  str_time = sprintf('Training: %3.0f/ %3.0f s',elap_t,tot_t);
  set(f,'Name', ['Learning progress: ' str_time]);
  figure(f)
  switch tracking
   case 1, 
   case 2,       
    plot(1:n,qe(1:n),(n+1):l,qe((n+1):l))
    title('Quantization errors for latest samples')    
    drawnow
   otherwise,
    subplot(2,1,1), plot(1:n,qe(1:n),(n+1):l,qe((n+1):l))
    title('Quantization error for latest samples');
    xlabel('Epochs');
    ylabel('Quantization error');
    subplot(2,1,2), 
    sw=plot(D.data(:,1),D.data(:,2),'b.'); 
    set(sw,'MarkerSize',6);
    hold on
    sw=plot(M.codebook(:,1),M.codebook(:,2),'ro');
    set(sw,'MarkerFaceColor','red');
    hold off
    title('First two components of map units (o) and data vectors (+)');
    drawnow
  end  
  % end of trackplot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
