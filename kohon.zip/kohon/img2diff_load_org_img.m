function img2diff_load_org_img

global org_img
global org_img_cm
global IMG2DIFF_image_1
global IMG2DIFF_image_2
global IMG2DIFF_image_3
global lw lc
global BackColor

text_res = findobj( 'Tag', 'Result_TEXT' );
set( text_res, 'Visible', 'off' );

if ~isempty('IMG2DIFF_image_1'),
   delete( IMG2DIFF_image_1 );
   IMG2DIFF_image_1 = [];
end
if ~isempty('IMG2DIFF_image_2'),
   delete( IMG2DIFF_image_2 );
   IMG2DIFF_image_2 = [];
end
if ~isempty('IMG2DIFF_image_3'),
   delete( IMG2DIFF_image_3 );
   IMG2DIFF_image_3 = [];
end

ax = findobj( 'Tag','IMG2DIFF_axes_1' );
set( ax, 'Box', 'on' );
set( ax, 'Color', BackColor )
set( ax, 'XTick', [] );
set( ax, 'YTick', [] );
set( ax, 'Visible', 'on' );

ax = findobj( 'Tag','IMG2DIFF_axes_2' );
set( ax, 'Box', 'on' );
set( ax, 'Color', BackColor )
set( ax, 'XTick', [] );
set( ax, 'YTick', [] );
set( ax, 'Visible', 'on' );

ax = findobj( 'Tag','IMG2DIFF_axes_3' );
set( ax, 'Box', 'on' );
set( ax, 'Color', BackColor )
set( ax, 'XTick', [] );
set( ax, 'YTick', [] );
set( ax, 'Visible', 'on' );

im_matlab_version = str2num(strtok(version, '.' )); 

%if im_matlab_version < 6,
   [filename, pathname] = uigetfile( '*.pcx', 'Select ORIGINAL file');
%else
%	[filename, pathname] = uigetfile( {'*.jpg;*.tif;*.bmp;*.pcx', 'All IMAGE files'; ...
%	        '*.*',          'All Files (*.*)'}, ...
%   	     'Select ORIGINAL file' );      
%end

if filename == 0,
	org_img = [];
	org_img_cm = [];
	return   
end

if ~isempty( pathname ) 
   fname = [pathname filename];
else
   fname = filename;
end

[im, cm] = imread( fname );

if length(size(im)) ~= 2,
   errordlg( 'Only grayscale images are allowed', 'Error', 'modal' );
   return
end

[lw, lc] = size( im );

org_img = im;
org_img_cm = cm;

cax = findobj( 'Tag', 'IMG2DIFF_axes_1' );
axes( cax );
IMG2DIFF_image_1 = image( im );
colormap( cm );
axis image off
set( cax, 'Tag','IMG2DIFF_axes_1' );

sec_butt = findobj( 'Tag', 'LoadRESImage' );
set( sec_butt, 'Enable', 'on' );