sM1=som_autolabel(sMap,sD,'vote');
sM=som_autolabel(sMap,sD,'freq');
som_show(sM,'empty','Labels','norm', 'd', 'empty','Labels','norm', 'd');
som_show_add('label',sM,'subplot',1);
som_show_add('label',sM1,'subplot',2);