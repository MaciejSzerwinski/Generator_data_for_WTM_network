function [dim, neigh, lattice, shape, ini_type, alg, epoch, radius, alpha, lambda]=kohon_config ;

dim = [5 7];

%neigh = {'bubble', 'gaussian', 'cutgaussian', 'ep' };
neigh = 'bubble';
lattice = 'hexa';
shape = 'sheet';
ini_type = 'randinit';

alg = 'CWTA';

epoch = 10;
radius = 1;
alpha = 0.5;
lambda = 1;