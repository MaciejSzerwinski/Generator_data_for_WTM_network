function img2koh_set_xdim_frames

global xdim_ramy
global xdim 

val = get( gcbo, 'String' );
val_num = str2num( val );

if isempty( val_num ),
   set( gcbo, 'String', num2str(get(gcbo,'Value')) );
   fprintf( '\a' );
else
   if mod(xdim,real(val_num) ) ~= 0 | ~isreal(val_num) ,
      uiwait(errordlg( 'Zly wymiar ramy', 'Blad', 'modal' ));
      set( gcbo, 'String', num2str(get(gcbo,'Value')) );
   else
      xdim_ramy = val_num;
      set( gcbo, 'Value', val_num );
      img2koh_compute;   
   end
end


