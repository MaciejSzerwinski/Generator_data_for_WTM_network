function [qe,te]=disp_errors(sMap, sD);

[qe,te] = som_quality(sMap,sD);
fprintf(['Mean quantization error = ' num2str(abs(qe)) ', topographic error = ' num2str(abs(te)) '\n'] );
