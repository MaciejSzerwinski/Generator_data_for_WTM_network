K = 100;
L = 10;

p=zeros(K,3);

%przesuniecie x+
p=zeros(K,3);
for k=1:K,
    p(k,:) = [randn randn randn];
end
p1=ones(size(p));
p1(:,1) = L*p1(:,1);
p1 = p + p1;

%przesuniecie x-
p=zeros(K,3);
for k=1:K,
    p(k,:) = [randn randn randn];
end
p2=ones(size(p));
p2(:,1) = L*p2(:,1);
p2 = p - p2;

%przesuniecie y+
p=zeros(K,3);
for k=1:K,
    p(k,:) = [randn randn randn];
end
p3=ones(size(p));
p3(:,2) = L*p3(:,2);
p3 = p + p3;

%przesuniecie y-
p=zeros(K,3);
for k=1:K,
    p(k,:) = [randn randn randn];
end
p4=ones(size(p));
p4(:,2) = L*p4(:,2);
p4 = p - p4;

%przesuniecie z+
p=zeros(K,3);
for k=1:K,
    p(k,:) = [randn randn randn];
end
p5=ones(size(p));
p5(:,3) = L*p5(:,3);
p5 = p + p5;

%przesuniecie z-
p=zeros(K,3);
for k=1:K,
    p(k,:) = [randn randn randn];
end
p6=ones(size(p));
p6(:,3) = L*p6(:,3);
p6 = p - p6;


p = [p1 ; p2; p3; p4; p5; p6];



figure(44)
plot3(p(:,1),p(:,2),p(:,3),'.');
axis([-L-5 L+5 -L-5 L+5 -L-5 L+5] )

save grupy3d p -ASCII