x1=randn(100,2);
x2=0.5*randn(100,2);
x3=0.3*randn(100,2);
x4=0.1*randn(100,2);

x=[x1;x2;x3;x4];
plot(x(:,1),x(:,2),'o')

save nonun.dat x -ASCII