function img2koh_compute;

global org_img 
global org_img_cm
global img_fname
global xdim 
global ydim
global xdim_ramy
global ydim_ramy
global rozm_ramy
global liczba_ram

rozm_ramy = xdim_ramy * ydim_ramy;
liczba_ram = floor(xdim / xdim_ramy) * floor(ydim / ydim_ramy);

% zapisy do editow
xdim_e = findobj( 'Tag','IMG2KOH_XDIM_EditText' );
set( xdim_e, 'Value', xdim );
set( xdim_e, 'String', int2str(xdim) );

ydim_e = findobj( 'Tag','IMG2KOH_YDIM_EditText' );
set( ydim_e, 'Value', ydim );
set( ydim_e, 'String', int2str(ydim) );

xdim_r_e = findobj( 'Tag','IMG2KOH_RAMA_XDIM_EditText' );
set( xdim_r_e, 'Value', xdim_ramy );
set( xdim_r_e, 'String', int2str(xdim_ramy) );
set( xdim_r_e, 'Enable', 'on' );

ydim_r_e = findobj( 'Tag','IMG2KOH_RAMA_YDIM_EditText' );
set( ydim_r_e, 'Value', ydim_ramy );
set( ydim_r_e, 'String', int2str(ydim_ramy) );
set( ydim_r_e, 'Enable', 'on' );

rozm_r_e = findobj( 'Tag','IMG2KOH_RAMA_ROZM_EditText' );
set( rozm_r_e, 'Value', rozm_ramy );
set( rozm_r_e, 'String', int2str(rozm_ramy) );

num_r_e = findobj( 'Tag','IMG2KOH_LICZBA_RAM_EditText' );
set( num_r_e, 'Value', liczba_ram );
set( num_r_e, 'String', int2str(liczba_ram) );

sbutt = findobj( 'Tag','IMG2KOH_SAVE_button' );
set( sbutt, 'Enable', 'on' );
	
